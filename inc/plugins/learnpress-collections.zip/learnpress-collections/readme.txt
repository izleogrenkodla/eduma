===  LearnPress Collection - WordPress extention for LearnPress ===  
Contributors: thimpress, kendy73, tunnhn  
Donate link:  
Tags: lms, elearning, e-learning, learning management system, education, course, courses, quiz, quizzes, questions, training, guru, sell courses  
Requires at least: 3.8  
Tested up to: 4.2.2  
Stable tag: 1.0
License: GPLv2 or later  
License URI: http://www.gnu.org/licenses/gpl-2.0.html  

LearnPress Collections is an extension plugin to group courses into collection for user demand.

== Description ==  
LearnPress Collections is an extension plugin to group courses into collection for user demand.

== Installation ==

**From your WordPress dashboard**  
1. Visit 'Plugin > Add new'.  
2. Search for 'LearnPress Collection'.  
3. Activate LearnPress from your Plugins page.  

**From WordPress.org**  
1. Search, select and download LearnPress Collection.  
2. Activate the plugin through the 'Plugins' menu in WordPress Dashboard.  

== Frequently Asked Questions ==  

Check out <a href="http://docs.thimpress.com/learnpress" target="_blank">LearnPress</a> sites.  

== Screenshots ==  


== Changelog ==

= 1.0 =
+ Compatible with LearnPress version 1.0

= 0.9.1 =  
The first beta release.

== Upgrade Notice ==  
Later :)

== Other note ==  
<a href="http://docs.thimpress.com/learnpress" target="_blank">Documentation</a> is available in ThimPress site.  
<a href="https://github.com/LearnPress/LearnPress/" target="_blank">LearnPress github repo.</a>  